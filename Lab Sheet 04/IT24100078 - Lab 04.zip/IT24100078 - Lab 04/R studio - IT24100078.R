setwd("C:\\Users\\IT24100078\\Desktop\\IT24100078 - Lab 04")
getwd()

#1
branch_data <- read.table("Exercise.txt",header = TRUE , sep = ",")

#2
head(branch_data)
str(branch_data)

#3
windows(width = 10,height = 7)
boxplot(branch_data$Sales_X1 , main = "Boxplot for sales")

#4
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

#5
get.outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  
  iqr <- q3 - q1
  
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  
  print(paste("Upper bound = ", ub))
  print(paste("Lower bound = ", lb))
  
  outliers <- sort(z[z < lb | z > ub])
  
  if (length(outliers)>0){
    print(paste("outliers :", paste(outliers, collapse = ",")))
  }else{
    print("NO outliers detected.")
  }
  
  
}
get.outliers(branch_data$Years_X3)